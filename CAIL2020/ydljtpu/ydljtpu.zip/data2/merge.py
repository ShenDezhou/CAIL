
import json

with open('train.json','r',encoding='utf-8') as f:
    with open('valid.json', 'r', encoding='utf-8') as fv:
        train2 = json.load(f)
        train1 = json.load(fv)
        for dic in train1:
            dic['_id'] += 5054
            train2.append(dic)
        with open('trainx.json', 'w', encoding='utf-8') as fw:
            json.dump(train2, fw, indent=4, ensure_ascii=False)
