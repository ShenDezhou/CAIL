{
  "type" : "https://www.jhipster.tech/problem/problem-with-message",
  "title" : "Not Acceptable",
  "status" : 406,
  "detail" : "Could not find acceptable representation",
  "path" : "/error",
  "message" : "error.http.406"
}